package com.example.deteling.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.deteling.databinding.ActivitySingBinding;

public class SingActivity extends BaseActivity {
    ActivitySingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setVariable();
    }

    private void setVariable() {
        binding.Sing.setOnClickListener(v -> {
            String email = binding.Email.getText().toString();
            String password = binding.Password.getText().toString();

            if (password.length() < 6) {
                Toast.makeText(SingActivity.this, "Пароль должен быть больше 6 символов", Toast.LENGTH_SHORT).show();
                return;
            }

            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "Регистрация успешна");
                            startActivity(new Intent(SingActivity.this, MainActivity.class));
                        } else {
                            Log.e(TAG, "Ошибка регистрации", task.getException());
                            Toast.makeText(SingActivity.this, "Регистрация не удалась", Toast.LENGTH_SHORT).show();
                        }
                    });
        });
    }
}