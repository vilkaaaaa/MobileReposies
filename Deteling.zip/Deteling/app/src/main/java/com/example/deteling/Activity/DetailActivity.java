package com.example.deteling.Activity;

import android.os.Bundle;

import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.example.deteling.Domain.Products;
import com.example.deteling.Helper.ManagmentCart;
import com.example.deteling.R;
import com.example.deteling.databinding.ActivityDetailBinding;

public class DetailActivity extends BaseActivity {
ActivityDetailBinding binding;
private Products object;
private int num = 1;
private ManagmentCart managmentCart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.brown));
        getIntentExtra();
        setVariable();
    }

    private void setVariable() {
        managmentCart = new ManagmentCart(this);
        binding.back.setOnClickListener(v -> finish());
        int drawableId = getResources().getIdentifier(object.getImg(), "drawable", getPackageName());
        Glide.with(this)
                .load(drawableId)
                .into(binding.Img);
        binding.price.setText(object.getPrice()+" Р.");
        binding.title.setText(object.getName());
        binding.desc.setText(object.getDescription());
        binding.totalpdetail.setText(num* object.getPrice()+" Р.");
        binding.plus.setOnClickListener(v -> {
            num = num+1;
            binding.num.setText(num + "");
            binding.totalpdetail.setText(num* object.getPrice()+" Р.");

        });
        binding.sub.setOnClickListener(v -> {
if(num>1){
num = num-1;
binding.num.setText(num + "");
binding.totalpdetail.setText(num* object.getPrice()+" Р.");
}
        });
        binding.add.setOnClickListener(v -> {
            object.setNumberInCart(num);
managmentCart.insertFood(object);
        });
    }

    private void getIntentExtra() {
        object = (Products) getIntent().getSerializableExtra("object");
    }
}