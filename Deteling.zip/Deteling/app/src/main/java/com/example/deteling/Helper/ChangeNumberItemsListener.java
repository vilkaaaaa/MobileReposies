package com.example.deteling.Helper;

public interface ChangeNumberItemsListener {
    void change();
}
