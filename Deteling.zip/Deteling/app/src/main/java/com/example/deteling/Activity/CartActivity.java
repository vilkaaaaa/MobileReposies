package com.example.deteling.Activity;

import android.os.Bundle;
import android.view.View;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.deteling.Adapter.CartAdapter;
import com.example.deteling.Helper.ManagmentCart;
import com.example.deteling.databinding.ActivityCartBinding;

public class CartActivity extends BaseActivity {
ActivityCartBinding binding;
private RecyclerView.Adapter adapter;
private ManagmentCart managmentCart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCartBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        managmentCart = new ManagmentCart(this);
        setVariable();
        calculeteCart();
        initList();
    }


    private void initList() {
        if(managmentCart.getListCart().isEmpty()){
            binding.isEmpty.setVisibility(View.VISIBLE);
            binding.scrollview.setVisibility(View.GONE);
        }
        else {
            binding.isEmpty.setVisibility(View.GONE);
            binding.scrollview.setVisibility(View.VISIBLE);
        }
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,false);
        binding.CartList.setLayoutManager(linearLayoutManager);
        adapter = new CartAdapter(managmentCart.getListCart(), this, () -> calculeteCart());
    binding.CartList.setAdapter(adapter);
    }

    private void setVariable() {
        binding.back.setOnClickListener(v -> finish());
    }
    private  void calculeteCart(){
        double total = managmentCart.getTotalFee();
        binding.Total2.setText(total +" Р.");
       binding.total.setText(total +" Р.");
    }
}