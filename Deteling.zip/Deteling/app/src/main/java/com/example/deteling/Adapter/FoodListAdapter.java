package com.example.deteling.Adapter;


import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.deteling.Activity.DetailActivity;
import com.example.deteling.Domain.Products;
import com.example.deteling.R;

import java.util.ArrayList;


public class FoodListAdapter extends RecyclerView.Adapter<FoodListAdapter.viewholder> {
    ArrayList<Products> items;
    Context context;
    public FoodListAdapter(ArrayList<Products> items){
        this.items = items;
    }
    @NonNull
    @Override
    public FoodListAdapter.viewholder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        context = parent.getContext();
        View inflate = LayoutInflater.from(context).inflate(R.layout.viewhoder_list_food,parent,false);
        return new viewholder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodListAdapter.viewholder holder, int position) {
        Products products = items.get(position);
        if (products != null) {
            holder.TitleT.setText(products.getName()); // Убедитесь, что `textViewName` правильно привязан
            holder.PriceT.setText("Р. "+ items.get(position).getPrice());; // Проверьте и это поле
        }
        Log.d("Adapter", "Binding Products: " + products.getName() + ", ImgPath: " + products.getImg());
        // holder.TitleT.setText(items.get(position).getName());
        // holder.PriceT.setText("Р."+ items.get(position).getPrice());
        try {
            // Получаем имя ресурса и удаляем расширение, если оно есть
            String imageName = products.getImg().replaceAll("\\.\\w+$", "");

            // Получаем ID ресурса
            int drawableResourceid = holder.itemView.getContext().getResources().getIdentifier(
                    imageName, "drawable", holder.itemView.getContext().getPackageName()
            );

            if (drawableResourceid != 0) {
                // Если ресурс найден, устанавливаем изображение
                holder.pic.setImageResource(drawableResourceid);
                Log.d("Adapter", "Drawable resource ID for " + imageName + ": " + drawableResourceid);
            } else {
                // Если ресурс не найден, fallback на изображение по умолчанию
                Log.e("Adapter", "Drawable resource not found for " + imageName);
                holder.pic.setImageResource(R.drawable.star); // Замените `star` на ваше изображение по умолчанию
            }

        } catch (Exception e) {
            Log.e("Adapter", "Error setting image: " + e.getMessage());
            holder.pic.setImageResource(R.drawable.search); // fallback изображение
        }
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("object", items.get(position));
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class viewholder extends RecyclerView.ViewHolder {
        TextView TitleT, PriceT;
        ImageView pic;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            TitleT = itemView.findViewById(R.id.Title);
            PriceT = itemView.findViewById(R.id.Price);
            pic = itemView.findViewById(R.id.Img);
            Log.d("ViewHolder", "textViewName: " + (TitleT != null));
            Log.d("ViewHolder", "textViewPrice: " + (PriceT != null));
            Log.d("ViewHolder", "textViewPrice: " + (pic != null));
        }
    }
}
