package com.example.deteling.Domain;


import java.io.Serializable;

public class Products implements Serializable {
    private int categoryId;
    private String description;
    private int id;
    private String img;
    private String name;
    private double price;
    private int NumberInCart;
    @Override
    public String toString() {
        return name;
    }
    public int getNumberInCart() {
        return NumberInCart;
    }
    public void setNumberInCart(int numberInCart) {
        NumberInCart = numberInCart;
    }
    public Products() {
    }
    public int getCategoryId() {
        return categoryId;
    }
    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getImg() {
        return img;
    }
    public void setImg(String img) {
        this.img = img;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
}
