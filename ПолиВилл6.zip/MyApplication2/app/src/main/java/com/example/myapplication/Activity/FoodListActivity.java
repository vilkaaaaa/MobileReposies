package com.example.myapplication.Activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Adapter.FoodListAdapter;
import com.example.myapplication.Domain.Products;
import com.example.myapplication.databinding.ActivityFoodListBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FoodListActivity extends BaseActivity {
ActivityFoodListBinding binding;
private RecyclerView.Adapter adapterListFood;
private int CategoryId;
private String CategoryName;
private String searchText;
private boolean isSearch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFoodListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getIntentExtra();
        initList();

    }

    private void initList() {
        DatabaseReference myRef = database.getReference("Products");
        binding.processBar.setVisibility(View.VISIBLE);
        ArrayList<Products> list = new ArrayList<>();
        Query query;
        if (isSearch){
            query = myRef.orderByChild("Title").startAt(searchText).endAt(searchText + '\uf8ff');
        }
        else {
            query = myRef.orderByChild("categoryId").equalTo(CategoryId);
        }
        // Используйте CategoryId для фильтрации
      //  Query query = myRef.orderByChild("categoryId").equalTo(CategoryId);

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.d("FoodListActivity", "Снимок базы данных: " + snapshot.getValue());
                if (snapshot.exists()) {
                    for (DataSnapshot issue : snapshot.getChildren()) {
                        Products products = issue.getValue(Products.class);
                        if (products != null) {
                            Log.d("FoodListActivity", "Product: " + products.getName());
                            list.add(products);
                        }
                    }
                    if (!list.isEmpty()) {
                        binding.FoodListView.setLayoutManager(new GridLayoutManager(FoodListActivity.this, 2));
                        adapterListFood = new FoodListAdapter(list);
                        binding.FoodListView.setAdapter(adapterListFood);
                    } else {
                        Log.w("FoodListActivity", "Список продуктов пуст!");
                    }
                }
                binding.processBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("FoodListActivity", "Ошибка при чтении из базы данных: " + databaseError.getMessage());
            }
        });
    }


    private void getIntentExtra() {
        CategoryId = getIntent().getIntExtra("categoryId",0);
        CategoryName = getIntent().getStringExtra("categoryName");
      searchText = getIntent().getStringExtra("text");
        isSearch= getIntent().getBooleanExtra("isSearch",false);
binding.Title.setText(CategoryName);
binding.Backbtn.setOnClickListener(v -> finish());
    }
}