package com.example.myapplication.Domain;

import java.util.Date;

public class ReservationRequest {
    private int userId;
    private String Date;

    public ReservationRequest(){
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
