package com.example.myapplication.Domain;

public class Category {
    private int Id; // Изменено с 'Id' на 'id'
    private String ImgPath;
    private String Name;

    public Category() {
        // Пустой конструктор, необходимый для Firebase
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getImgPath() {
        return ImgPath;
    }

    public void setImgPath(String imgPath) {
        ImgPath = imgPath;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }
}
