package com.example.myapplication.Domain;

import java.util.Date;
import java.util.List;
public class Order {
    public int Id;
    public int UserId;
    public List<OrderItem> ProductList;
    public double TotalPrice;
    public Date TimesTamp;
    private String Status;

    public Order() {
    }

    // Геттеры и сеттеры
    public int getId() {
        return Id;
    }

    public int getUserId() {
        return UserId;
    }


    public double getTotalPrice() {
        return TotalPrice;
    }

    public Date getTimesTamp() {
        return TimesTamp;
    }

    public String getStatus() {
        return Status; // Геттер для статуса
    }

    public void setId(int id) {
        Id = id;
    }

    public void setUserId(int userId) {
        UserId = userId;
    }


    public void setTotalPrice(double totalPrice) {
        TotalPrice = totalPrice;
    }

    public void setTimesTamp(Date timesTamp) {
        this.TimesTamp= timesTamp;
    }

    public void setStatus(String status) {
        Status = status; // Сеттер для статуса
    }
}


