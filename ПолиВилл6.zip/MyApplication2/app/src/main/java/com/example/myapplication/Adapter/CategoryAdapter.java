package com.example.myapplication.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.nfc.Tag;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myapplication.Activity.FoodListActivity;
import com.example.myapplication.Domain.Category;
import com.example.myapplication.R;

import java.util.ArrayList;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.viewholder>{
    ArrayList<Category> items;
Context context;
public CategoryAdapter(ArrayList<Category>items, Context context){
    this.items = items;
    this.context = context;
}

    @NonNull
@Override
public CategoryAdapter.viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    context= parent.getContext();
    View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.vieholder_category,parent,false);
    return new viewholder(inflate);
}


    @Override
    public void onBindViewHolder(@NonNull CategoryAdapter.viewholder holder, int position) {
        Category category = items.get(position);
        holder.titleTxt.setText(items.get(position).getName());
        Log.d("Adapter", "Binding category: " + category.getName() + ", ImgPath: " + category.getImgPath());
switch (position){
    case 0:{
        holder.pic.setBackgroundResource(R.drawable.cat_back_0);
        break;
    }
    case 1:{
        holder.pic.setBackgroundResource(R.drawable.cat_back_1);
        break;
    }
    case 2:{
        holder.pic.setBackgroundResource(R.drawable.cat_back_2);
        break;
    }
}
        try {
            // Получаем имя ресурса и удаляем расширение, если оно есть
            String imageName = category.getImgPath().replaceAll("\\.\\w+$", "");

            // Получаем ID ресурса
            int drawableResourceid = holder.itemView.getContext().getResources().getIdentifier(
                    imageName, "drawable", holder.itemView.getContext().getPackageName()
            );

            if (drawableResourceid != 0) {
                // Если ресурс найден, устанавливаем изображение
                holder.pic.setImageResource(drawableResourceid);
                Log.d("Adapter", "Drawable resource ID for " + imageName + ": " + drawableResourceid);
            } else {
                // Если ресурс не найден, fallback на изображение по умолчанию
                Log.e("Adapter", "Drawable resource not found for " + imageName);
                holder.pic.setImageResource(R.drawable.star); // Замените `star` на ваше изображение по умолчанию
            }

        } catch (Exception e) {
            Log.e("Adapter", "Error setting image: " + e.getMessage());
            holder.pic.setImageResource(R.drawable.search); // fallback изображение
        }
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, FoodListActivity.class);
            intent.putExtra("categoryId",items.get(position).getId());
            intent.putExtra("categoryName",items.get(position).getName());
            context.startActivity(intent);
        });
    }

    @Override
public int getItemCount() {
    return items.size();
}
public static class viewholder extends RecyclerView.ViewHolder {
    TextView titleTxt;
    ImageView pic;
    public viewholder(@NonNull View itemView) {
        super(itemView);
        titleTxt = itemView.findViewById(R.id.NameC);
        pic = itemView.findViewById(R.id.catImg);
    }
}
}
