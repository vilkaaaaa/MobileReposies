package com.example.myapplication.Adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.RoundedCorner;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.example.myapplication.Activity.DetailActivity;
import com.example.myapplication.Domain.Products;
import com.example.myapplication.Helper.ChangeNumberItemsListener;
import com.example.myapplication.Helper.ManagmentCart;
import com.example.myapplication.R;

import java.util.ArrayList;

public class CartAdapter  extends RecyclerView.Adapter<CartAdapter.viewholder> {
    ArrayList<Products> list;
    private ManagmentCart managmentCart;
    ChangeNumberItemsListener changeNumberItemsListener;

    public CartAdapter(ArrayList<Products> list, Context context, ChangeNumberItemsListener changeNumberItemsListener) {
        this.list = list;
        managmentCart = new ManagmentCart(context);
        this.changeNumberItemsListener = changeNumberItemsListener;
    }

    @NonNull
    @Override
    public CartAdapter.viewholder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_cart,parent,false);
        return new viewholder(inflate);
    }
    private int getDrawableResourceId(String resourceName, Context context) {
        return context.getResources().getIdentifier(resourceName, "drawable", context.getPackageName());
    }

    @Override
    public void onBindViewHolder(@NonNull CartAdapter.viewholder holder, int position) {

    holder.titleT.setText(list.get(position).getName());
        holder.Price.setText(list.get(position).getPrice()+" Р.");
        holder.total.setText((
                list.get(position).getNumberInCart()*list.get(position).getPrice()+" Р."));
        holder.num.setText(list.get(position).getNumberInCart()+"");

        Glide.with(holder.itemView.getContext())
                .load(getDrawableResourceId(list.get(position).getImg(), holder.itemView.getContext()))
                .transform(new CenterCrop(), new RoundedCorners(30))
                .into(holder.pic);


        holder.plus.setOnClickListener(v -> managmentCart.plusNumberItem(list, position, new ChangeNumberItemsListener() {
          @Override
          public void change() {
              notifyDataSetChanged();
              changeNumberItemsListener.change();
          }
      }));
      holder.minus.setOnClickListener(v -> managmentCart.minusNumberItem(list, position, () -> {
          notifyDataSetChanged();
          changeNumberItemsListener.change();
      }));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class viewholder extends RecyclerView.ViewHolder {
        TextView titleT,plus, minus,Price;
        ImageView pic;
        TextView total, num;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            titleT= itemView.findViewById(R.id.title);
            pic= itemView.findViewById(R.id.foto);
            plus= itemView.findViewById(R.id.plus);
            minus= itemView.findViewById(R.id.sub);
            total= itemView.findViewById(R.id.Many);
            num= itemView.findViewById(R.id.num);
            Price= itemView.findViewById(R.id.price);

        }
    }
}
