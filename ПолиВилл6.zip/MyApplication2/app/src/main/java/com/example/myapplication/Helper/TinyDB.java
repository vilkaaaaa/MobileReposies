package com.example.myapplication.Helper;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.preference.PreferenceManager;

import com.example.myapplication.Domain.Products;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class TinyDB {
    private SharedPreferences preferences;
    private Gson gson; // Добавляем переменную Gson
    private String DEFAULT_APP_IMAGEDATA_DIRECTORY;
    private String lastImagePath = "";

    public TinyDB(Context context) {
        preferences = PreferenceManager.getDefaultSharedPreferences(context);
        gson = new Gson(); // Инициализация объекта Gson
    }

    public Bitmap getImg(String path) {
        Bitmap bitmapFromPath = null;
        try {
            bitmapFromPath = BitmapFactory.decodeFile(path);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmapFromPath;
    }

    public String getSavedImagePath() {
        return lastImagePath;
    }

    public void putListObject(String key, ArrayList<Products> list) {
        String json = gson.toJson(list); // Преобразование списка в JSON
        preferences.edit().putString(key, json).apply();
    }

    public ArrayList<Products> getListObject(String key) {
        String json = preferences.getString(key, null);
        if (json == null) {
            return new ArrayList<>(); // Возвращаем пустой список, если данных нет
        }
        Type type = new TypeToken<ArrayList<Products>>() {}.getType();
        return gson.fromJson(json, type); // Преобразование JSON обратно в список
    }
}
