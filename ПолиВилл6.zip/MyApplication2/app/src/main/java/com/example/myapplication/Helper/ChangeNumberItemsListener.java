package com.example.myapplication.Helper;

public interface ChangeNumberItemsListener {
    void change();
}
