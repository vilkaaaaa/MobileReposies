package com.example.myapplication.Domain;

import java.util.Date;

public class Reservation {
    private int userId;
    private Date date;

    public Reservation(int userId, Date date) {
        this.userId = userId;
        this.date = date;
    }

    public int getUserId() {
        return userId;
    }

    public Date getDate() {
        return date;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
