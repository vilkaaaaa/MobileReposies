package com.example.myapplication.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Adapter.CategoryAdapter;
import com.example.myapplication.Domain.Category;
import com.example.myapplication.databinding.ActivityMainBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends BaseActivity {
    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Инициализация категорий
        initCategory();
        setVariable();
    }

    private void setVariable() {
        binding.addcar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CartActivity.class));
            }
        });
    }

    private void initCategory() {
        DatabaseReference myRef = database.getReference("Category");
        binding.progressBar.setVisibility(View.VISIBLE); // Показываем прогресс-бар
        ArrayList<Category> list = new ArrayList<>();

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.d("Firebase", "Snapshot received: " + snapshot.toString()); // Выводим весь snapshot
                if (snapshot.exists()) {
                    for (DataSnapshot issue : snapshot.getChildren()) {
                        Category category = issue.getValue(Category.class);
                        if (category != null) {
                            Log.d("Firebase", "Category loaded: " + category.getName() + ", ImgPath: " + category.getImgPath());
                            list.add(category);
                        } else {
                            Log.e("Firebase", "Null category for key: " + issue.getKey());
                        }
                    }

                    if (!list.isEmpty()) {
                        binding.CatView.setLayoutManager(new GridLayoutManager(MainActivity.this, 3));
                        RecyclerView.Adapter<CategoryAdapter.viewholder> adapter = new CategoryAdapter(list, MainActivity.this);
                        binding.CatView.setAdapter(adapter);
                        Log.d("Firebase", "Adapter set with " + list.size() + " items.");
                    } else {
                        Log.e("Firebase", "No categories loaded.");
                    }
                } else {
                    Log.e("Firebase", "No snapshot data found.");
                }
                binding.progressBar.setVisibility(View.GONE);
            }



            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("TAG", "Database error: " + databaseError.getMessage());
                binding.progressBar.setVisibility(View.GONE); // Прячем прогресс-бар
            }
        });
    }
}
