package com.example.myapplication.Domain;

public class OrderItem {
    public int ProductId;
    public int Quantity;
    Products products = new Products();

    public OrderItem(){}

    public int getProductId() {
        return ProductId;
    }

    public void setProductId(int productId) {
        ProductId = productId;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }
}
